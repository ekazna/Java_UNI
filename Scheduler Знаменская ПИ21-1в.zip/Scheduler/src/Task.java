import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

class Task {
    int id; // Номер - должен генерироваться автоматически
    Calendar creationDate; // Дата создания
    Calendar dueDate; // Дата выполнения
    String name; // Наименование
    String description; // Детальное описание
    boolean done; // Выполнено ли

    Task(String name, Calendar dueDate){
        this.name = name;
        this.dueDate = dueDate;
        this.description = "";
        this.done = false;
        this.id = 0;
        this.creationDate = Calendar.getInstance();
    }

    Task(String name, Calendar dueDate, String description){
        this.name = name;
        this.dueDate = dueDate;
        this.description = description;
        this.done = false;
        this.id = 0;
        this.creationDate = Calendar.getInstance();
    }


    // Печать любой даты в формате dd.mm.yyyy
    public void printDate(Calendar cal){
        Date date = cal.getTime();
        SimpleDateFormat dt1 = new SimpleDateFormat("dd.MM.yyyy");
        System.out.println(dt1.format(date));
    }

    // Описание задания
    public void describeTask() {
        System.out.println("***************************************************************************");
        System.out.print("Task #" + this.id + ": *" + this.name + "* was created on ");
        printDate(this.creationDate);
        System.out.print("The due date is ");
        printDate(this.dueDate);
        System.out.println("Description: " + this.description);
        if (this.done){
            System.out.println("This task is DONE");
        }else {
            System.out.println("This task is NOT DONE");
        }
        System.out.println("***************************************************************************");
    }
}

