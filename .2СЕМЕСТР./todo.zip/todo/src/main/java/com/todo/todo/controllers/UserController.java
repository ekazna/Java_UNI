package com.todo.todo.controllers;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.todo.todo.models.Task;
import com.todo.todo.models.User;
import com.todo.todo.services.TaskService;
import com.todo.todo.services.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    UserService userService;

    @Autowired
    TaskService taskService;

    @GetMapping("") //посмотреть список всех пользователей
    public List<User> getAllUsers(){
        return userService.getAllUsers();
    }

    @GetMapping("/{id}") //найти пользователя по id
    public ResponseEntity<User> getUser(@PathVariable Integer id){
        try{
            User user = userService.getUserById(id);
            return new ResponseEntity<User>(user, HttpStatus.OK);
        }catch(NoSuchElementException e){
            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/name/{name}") // найти пользователя по имени
    public List<User> getUsersByName(@PathVariable String name){
        return userService.getUsersByName(name);
    }

    @PostMapping("/") // добавить пользователя
    public void addUser(@RequestBody User user){
        userService.saveUser(user);
    }

    @PutMapping("/{id}") // изменить данные о пользователе по id
    public ResponseEntity<?> updateUser(@RequestBody User user, @PathVariable Integer id){
        try{
            User oldUser = userService.getUserById(id);
            oldUser.updateUser(user);
            userService.saveUser(oldUser);
            return new ResponseEntity<>(HttpStatus.OK);
        }catch(NoSuchElementException e){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")  //удалить пользователя
    public void deleteUser(@PathVariable Integer id){
        userService.deleteUser(id);
    }

    @PostMapping("/{userId}/newtask/") // создать новое задание от имени пользователя
    public void addTask(@PathVariable Integer userId, @RequestBody Task task){
        User user = userService.getUserById(userId);
        task.setUser(user);
        taskService.saveTask(task);
    }
}
