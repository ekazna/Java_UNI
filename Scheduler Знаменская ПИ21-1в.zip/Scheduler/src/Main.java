import java.util.*;

public class Main {
    public static void main(String[] args) {

        Schedule mySchedule = new Schedule();

        // Добавляем несколько заданий в планировщик
        mySchedule.addTask("Algebra", setDate("28.12.2023"), "ex: 1, 2, 3");
        mySchedule.addTask("Biology", setDate("28.12.2023"), "draw a plant cell");
        mySchedule.addTask("Biology", setDate("23.12.2023"), "draw an animal cell");
        mySchedule.addTask("Chemistry", setDate("23.12.2023"), "learn new equations");
        mySchedule.addTask("Drama", setDate("23.12.2023"), "write a script for a play");


        System.out.println("\n** Чтобы увидеть список доступных команд введите HELP **\n");
        Scanner scanner = new Scanner(System.in);

        while (true){
            System.out.println("Введите команду: ");
            String command = scanner.nextLine().trim();
            if (command.equalsIgnoreCase("create")||command.equalsIgnoreCase("Создать") || command.equalsIgnoreCase("#1")){
                create(scanner, mySchedule);
                // #1 ** Создать ** //

            } else if (command.equalsIgnoreCase("delete")||command.equalsIgnoreCase("Удалить") || command.equalsIgnoreCase("#2")) {
                delete(scanner, mySchedule);
                // #2 ** Удалить ** //

            } else if (command.equalsIgnoreCase("edit") || command.equalsIgnoreCase("Отредактировать")|| command.equalsIgnoreCase("#3")) {
                edit(scanner, mySchedule);
                // #3 ** Отредактировать ** //

            } else if (command.equalsIgnoreCase("complete")||command.equalsIgnoreCase("Выполнить")||command.equalsIgnoreCase("#4")) {
                complete(scanner, mySchedule);
                // #4 ** Отметить как выполненное ** //

            } else if (command.equalsIgnoreCase("info")||command.equalsIgnoreCase("describe")||command.equalsIgnoreCase("Информация")||command.equalsIgnoreCase("#5")) {
                info(scanner, mySchedule);
                // #5 ** Получить детальную информацию ** //

            } else if (command.equalsIgnoreCase("see all")||command.equalsIgnoreCase("#6.1")) {
                System.out.println("[ВСЕ ЗАДАНИЯ]");
                mySchedule.printAllTasks();
                // #6.1 ** Просмотреть список ВСЕХ заданий ** //

            } else if (command.equalsIgnoreCase("see done") ||command.equalsIgnoreCase("#6.2")) {
                System.out.println("[ВСЕ ВЫПОЛНЕННЫЕ]");
                mySchedule.printDoneTasks();
                // #6.2 ** Просмотреть список ВЫПОЛНЕННЫХ заданий ** //

            } else if (command.equalsIgnoreCase("see undone") ||command.equalsIgnoreCase("#6.3")) {
                System.out.println("[ВСЕ НЕВЫПОЛНЕННЫЕ]");
                mySchedule.printUndoneTasks();
                // #6.3 ** Просмотреть список НЕВЫПОЛНЕННЫХ заданий ** //

            } else if (command.equalsIgnoreCase("see all by due date")||command.equalsIgnoreCase("#7.1")) {
                System.out.println("[список ВСЕХ на дату ВЫПОЛНЕНИЯ]");
                seeAllByDueDate(scanner, mySchedule);
                // #7.1 ** ВСЕХ на дату ВЫПОЛНЕНИЯ ** //

            } else if (command.equalsIgnoreCase("see done by due date")||command.equalsIgnoreCase("#7.2")) {
                System.out.println("[список ВЫПОЛНЕННЫХ на дату ВЫПОЛНЕНИЯ]");
                seeDoneByDueDate(scanner, mySchedule);
                // #7.2 ** ВЫПОЛНЕННЫХ на дату ВЫПОЛНЕНИЯ ** //

            } else if (command.equalsIgnoreCase("see undone by due date")||command.equalsIgnoreCase("#7.3")) {
                System.out.println("[список НЕВЫПОЛНЕННЫХ на дату ВЫПОЛНЕНИЯ]");
                seeUndoneByDueDate(scanner, mySchedule);
                // #7.3 ** НЕВЫПОЛНЕННЫХ на дату ВЫПОЛНЕНИЯ ** //

            } else if (command.equalsIgnoreCase("see all by creation date")||command.equalsIgnoreCase("#8.1")) {
                System.out.println("[список ВСЕХ на дату СОЗДАНИЯ]");
                seeAllByCreationDate(scanner, mySchedule);
                // #8.1 ** ВСЕХ на дату СОЗДАНИЯ ** //

            } else if (command.equalsIgnoreCase("see done by creation date")||command.equalsIgnoreCase("#8.2")) {
                System.out.println("[список ВЫПОЛНЕННЫХ на дату СОЗДАНИЯ]");
                seeDoneByCreationDate(scanner, mySchedule);
                // #8.2 ** ВЫПОЛНЕННЫХ на дату СОЗДАНИЯ ** //

            } else if (command.equalsIgnoreCase("see undone by creation date")||command.equalsIgnoreCase("#8.3")) {
                System.out.println("[список НЕВЫПОЛНЕННЫХ на дату СОЗДАНИЯ]");
                seeUndoneByCreationDate(scanner, mySchedule);
                // #8.3 ** НЕВЫПОЛНЕННЫХ на дату СОЗДАНИЯ ** //

            } else if (command.equalsIgnoreCase("help")||command.equalsIgnoreCase("Помощь")) {
                help();

            } else if (command.equalsIgnoreCase("exit")||command.equalsIgnoreCase("Выход")){
                System.out.println("*** Bye-bye ***");
                break;

            }else{
                System.out.println("Такой команды не существует");
                System.out.println("Чтобы увидеть список доступных команд введите HELP");
            }
        }
    }

// методы можно перенести и сделать методами SCHEDULE, заменив mySchedule на this и добавив несколько правок

// Проверяет дату
    public static boolean checkDate(String str) {
        if (!str.contains(".")) {
            return false;
        }
        String[] dateList = str.split("\\.");
        if (dateList.length != 3) {
            return false;
        }
        try {
            int day = Integer.parseInt(dateList[0]);
            int month = Integer.parseInt(dateList[1]);
            int year = Integer.parseInt(dateList[2]);
            Calendar newcal = new GregorianCalendar();
            newcal.setLenient(false);
            try{
                newcal.set(year, month-1, day);
                newcal.getTime();
            }catch (Exception e){
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }

// Устанавливает дату, используется только если дата уже проверена
    public static Calendar setDate(String str){
        // Делит строку на части и присваивает значения календарю
        String[] dateList = str.split("\\.");
        int day = Integer.parseInt(dateList[0]);
        int month = Integer.parseInt(dateList[1]);
        int year = Integer.parseInt(dateList[2]);
        Calendar newcal = new GregorianCalendar();
        newcal.setLenient(false); // не дает выходить за пределы нормальных дат
        newcal.set(year, month-1, day);
        return newcal;
    }

// проверяет что имя не начинается с цифры
    public static boolean checkName(String name){
        if (!name.equals("")) {
            return !Character.isDigit(name.charAt(0));
        } return true;
    }

// Возвращает какая дата позже - первая или вторая (или 0, если равны)
    public static int laterDate(Calendar date1, Calendar date2) {
        if (date1.get(Calendar.YEAR) > date2.get(Calendar.YEAR)){
            return 1;
        } else if (date1.get(Calendar.YEAR) == date2.get(Calendar.YEAR)) {
            if (date1.get(Calendar.MONTH) > date2.get(Calendar.MONTH)){
                return 1;
            } else if (date1.get(Calendar.MONTH) == date2.get(Calendar.MONTH)) {
                if (date1.get(Calendar.DATE) > date2.get(Calendar.DATE)){
                    return 1;
                }else if(date1.get(Calendar.DATE) > date2.get(Calendar.DATE)){
                    return 0;
                }
            }
        }
        return 2;
    }

// Ищет задание в планировщике по id или по имени
    public static Task findTask(String name, Schedule mySchedule, Scanner scanner){
        if (checkName(name)){   // если ввод начинается не с цифры, то это имя
            int counter = 0;
            ArrayList<Task> task_list = new ArrayList<>();
            for (Task task: mySchedule.mySchedule) {
                if (task.name.equalsIgnoreCase(name)){
                    task_list.add(task);
                    counter ++;
                }
            }
            if (counter == 1){    // такое задание есть
                return task_list.get(0);
            } else if (counter == 0) {   // такого задания нет
                return null;
            } else{      //таких заданий несколько
                System.out.println("Есть несколько задач с таким названием");
                for (Task task:task_list) {
                    task.describeTask();
                }
                while (true){
                    System.out.println("Выберите задачу и напишите её ID");
                    try{
                        int num = Integer.parseInt(scanner.nextLine());
                        for (Task task:task_list) {
                            if (task.id == num){
                                return task;
                            }
                        }
                        System.out.println("Неверный ID");
                    }catch (NumberFormatException e){
                        System.out.println("Введен неверный ID");
                    }
                }

            }
        } else{  //если ввод начинается с цифры, то ищет по ID
            int taskID;
            try{
                taskID = Integer.parseInt(name);
            }catch (NumberFormatException e){
                System.out.println("Введен неверный ID");
                return null;
            }
            for (Task task: mySchedule.mySchedule) {
                if (task.id - taskID == 0){
                    return task;
                }
            }
            return null;
        }
    }


// Дальше идут методы для команд - создание, удаление, редактирование, выполнение, информация и различный вывод
    public static void create(Scanner scanner, Schedule mySchedule) {

        String name;
        while (true) {
            System.out.println("Введите ИМЯ задания (не может начинаться с цифры, не может быть словом exit)");
            name = scanner.nextLine().trim();
            if (name.equalsIgnoreCase("exit")) {
                return;
            } else if (!checkName(name)) {
                System.out.println("Некорректное имя, попробуйте снова");
                System.out.println("Для отмены введите exit");
            } else { // имя подходит
                break;
            }
        }
        System.out.println("Введите ОПИСАНИЕ задания (или оставьте поле пустым и нажмите ENTER)");
        String description = scanner.nextLine().trim();

        String date;
        while (true) { // проверяет дату
            System.out.println("Введите дедлайн в формате dd.mm.yyyy, например 15.04.2020");
            date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("exit")) {
                return;
            } else if (!checkDate(date)) {
                System.out.println("Некорректная дата, попробуйте снова");
                System.out.println("Для отмены введите exit");
            } else {
                if (laterDate(setDate(date), Calendar.getInstance()) == 2){
                    System.out.println("Этот дедлайн раньше даты создания задания. Попробуйте снова или введите exit");
                }else {
                    break; // дата подходит
                }
            }
        }
        mySchedule.addTask(name, setDate(date), description);

    }

    public static void delete(Scanner scanner, Schedule mySchedule){
        while(true){
            System.out.println("Введите имя или ID задачи для УДАЛЕНИЯ");
            String name = scanner.nextLine().trim();
            if (name.equalsIgnoreCase("exit")) {
                return;
            }
            Task task = findTask(name, mySchedule, scanner); // поиск задания по имени/id
            if (task != null){
                mySchedule.mySchedule.remove(task);
                System.out.println("Задача удалена");
                return;
            } else {
                System.out.println("Такой задачи не существует");
                System.out.println("Попробуйте снова или введите exit");
            }
        }
    }

    public static void edit(Scanner scanner, Schedule mySchedule){
        while(true){
            System.out.println("Введите имя или ID задачи для РЕДАКТИРОВАНИЯ");
            String name = scanner.nextLine().trim();
            if (name.equalsIgnoreCase("exit")) {
                return;
            }
            Task task = findTask(name, mySchedule, scanner); // ищет задачу по имени или id
            if (task != null){
                while (true){
                    System.out.println("Что вы хотите изменить? Введите due date, name или description. Или цифры 1, 2 или 3 соотвественно");
                    String what = scanner.nextLine().trim();

                    //смена деделайна + проверка даты
                    if (what.equalsIgnoreCase("due date")||what.equalsIgnoreCase("1")){
                        System.out.print("Сейчас дедлайн задания: ");
                        task.printDate(task.dueDate);
                        System.out.println("На что его заменить? (для отмены введите exit). Формат dd.mm.yyyy, например 15.04.2020");
                        String change = scanner.nextLine().trim();
                        if (!change.equalsIgnoreCase("exit")) {
                            if (checkDate(change)){  //дата в правильном формате
                                Calendar date_change = setDate(change);
                                if (laterDate(date_change, task.creationDate) == 2){
                                    System.out.println("Этот дедлайн раньше даты создания задания. Попробуйте снова");
                                }else {
                                    task.dueDate = date_change;
                                    System.out.println("Дедлайн изменен");
                                    return;
                                }
                            } else {
                                System.out.println("Неверное введена дата, попробуйте снова");
                            }
                        }else {
                            return;
                        }

                        // изменение имени + проверка на отсутсвие в начале цифры
                    }else if (what.equalsIgnoreCase("name")||what.equalsIgnoreCase("2")){
                        System.out.print("Сейчас имя задания: ");
                        System.out.println(task.name);
                        System.out.println("На что его заменить? (для отмены введите exit). Имя не может начинаться с цифры, не может быть словом exit");
                        String change = scanner.nextLine().trim();
                        if (!change.equalsIgnoreCase("exit")) {
                            if (checkName(change)){
                                task.name = change;
                                System.out.println("Имя изменено");
                                return;
                            } else {
                                System.out.println("Такое имя не подходит, попробуйте снова");
                            }
                        }else {
                            return;
                        }

                        // изменение описания
                    } else if (what.equalsIgnoreCase("description")||what.equalsIgnoreCase("3")) {
                        System.out.println("Сейчас описание задания: ");
                        System.out.println(task.description);
                        System.out.println("На что его заменить? (для отмены введите exit)");
                        String change = scanner.nextLine().trim();
                        if (!change.equalsIgnoreCase("exit")) {
                            task.description = change;
                            System.out.println("Описание изменено");
                        }
                        return;
                    } else if (what.equalsIgnoreCase("exit")){
                        return;
                    } else{ // фильтр ошибок при вводе
                        System.out.println("У задания нет такого свойства и его нельзя изменить");
                        System.out.println("Попробуйте снова или введите exit");
                    }
                }
            } else {
                System.out.println("Такой задачи не существует");
                System.out.println("Попробуйте снова или введите exit");
            }
        }
    }

    public static void complete(Scanner scanner, Schedule mySchedule){
        while(true){
            System.out.println("Введите имя или ID задачи, которую вы ВЫПОЛНИЛИ");
            String name = scanner.nextLine().trim();
            if (name.equalsIgnoreCase("exit")) {
                return;
            }
            Task task = findTask(name, mySchedule, scanner); // поиск задачи по имени или номеру
            if (task != null){
                if (task.done){
                    System.out.println("Задача уже была выполнена");
                } else{
                    task.done = true;
                    //task.dueDate = Calendar.getInstance();
                    System.out.println("Задача выполнена!");
                }
                return;
            } else {
                System.out.println("Такой задачи не существует");
                System.out.println("Попробуйте снова или введите exit");
            }
        }
    }

    public static void info(Scanner scanner, Schedule mySchedule){
        while(true){
            System.out.println("Введите имя или ID задачи для ПОЛУЧЕНИЯ ИНФОРМАЦИИ");
            String name = scanner.nextLine().trim();
            if (name.equalsIgnoreCase("exit")) {
                return;
            }

            if (checkName(name)){ // если было введено имя а не id
                int counter = 0;
                ArrayList<Task> task_list = new ArrayList<>();
                for (Task task: mySchedule.mySchedule) { //смотрит сколько есть заданий с таким именем
                    if (task.name.equalsIgnoreCase(name)){
                        task_list.add(task);
                        counter ++;
                    }
                }
                if (counter == 1){
                    task_list.get(0).describeTask();
                    return;
                } else if (counter == 0) {
                    System.out.println("Такой задачи не существует");
                    System.out.println("Попробуйте снова или введите exit");
                } else{  // если задач с одним именем несколько - выводит описание их всех
                    System.out.println("Есть несколько задач с похожим названием");
                    for (Task task:task_list) {
                        task.describeTask();
                    }
                    return;
                }
            } else{  // если был введен номер, а не имя
                int taskID = 0;
                try{
                    taskID = Integer.parseInt(name);
                }catch (NumberFormatException e){
                    System.out.println("Введен неверный ID");
                    System.out.println("Попробуйте снова или введите exit");
                }
                for (Task task: mySchedule.mySchedule) {
                    if (task.id - taskID == 0){
                        task.describeTask(); // выводит описание если такое задание есть
                        return;
                    }
                }
                System.out.println("Введен неверный ID");
                System.out.println("Попробуйте снова или введите exit");
            }
        }
    }

    // все методы похожи, проверяют правильность даты и выводят соответсвенные задания
    public static void seeAllByDueDate(Scanner scanner, Schedule mySchedule){
        while (true){
            System.out.println("Введите дедлайн в формате dd.mm.yyyy, например 15.04.2020");
            String date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("exit")) {
                return;
            }
            if (checkDate(date)){
                mySchedule.printAllTasksByDueDate(setDate(date));
                return;
            }else{
                System.out.println("Некорректная дата, попробуйте снова");
                System.out.println("Для отмены введите exit");
            }
        }
    }

    public static void seeDoneByDueDate(Scanner scanner, Schedule mySchedule){
        while (true){
            System.out.println("Введите дедлайн в формате dd.mm.yyyy, например 15.04.2020");
            String date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("exit")) {
                return;
            }
            if (checkDate(date)){
                mySchedule.printDoneTasksByDueDate(setDate(date));
                return;
            }else{
                System.out.println("Некорректная дата, попробуйте снова");
                System.out.println("Для отмены введите exit");
            }
        }
    }

    public static void seeUndoneByDueDate(Scanner scanner, Schedule mySchedule){
        while (true){
            System.out.println("Введите дедлайн в формате dd.mm.yyyy, например 15.04.2020");
            String date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("exit")) {
                return;
            }
            if (checkDate(date)){
                mySchedule.printUndoneTasksByDueDate(setDate(date));
                return;
            }else{
                System.out.println("Некорректная дата, попробуйте снова");
                System.out.println("Для отмены введите exit");
            }
        }
    }

    public static void seeAllByCreationDate(Scanner scanner, Schedule mySchedule){
        while (true){
            System.out.println("Введите дату создания в формате dd.mm.yyyy, например 15.04.2020");
            String date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("exit")) {
                return;
            }
            if (checkDate(date)){
                mySchedule.printAllTasksByCreationDate(setDate(date));
                return;
            }else{
                System.out.println("Некорректная дата, попробуйте снова");
                System.out.println("Для отмены введите exit");
            }
        }
    }

    public static void seeDoneByCreationDate(Scanner scanner, Schedule mySchedule){
        while (true){
            System.out.println("Введите дату создания в формате dd.mm.yyyy, например 15.04.2020");
            String date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("exit")) {
                return;
            }
            if (checkDate(date)){
                mySchedule.printDoneTasksByCreationDate(setDate(date));
                return;
            }else{
                System.out.println("Некорректная дата, попробуйте снова");
                System.out.println("Для отмены введите exit");
            }
        }
    }

    public static void seeUndoneByCreationDate(Scanner scanner, Schedule mySchedule){
        while (true){
            System.out.println("Введите дату создания в формате dd.mm.yyyy, например 15.04.2020");
            String date = scanner.nextLine().trim();
            if (date.equalsIgnoreCase("exit")) {
                return;
            }
            if (checkDate(date)){
                mySchedule.printUndoneTasksByCreationDate(setDate(date));
                return;
            }else{
                System.out.println("Некорректная дата, попробуйте снова");
                System.out.println("Для отмены введите exit");
            }
        }
    }


    public static void help(){
        System.out.println("\u001B[1m\nКоманды можно вызывать по кодовым именам или по номерам, например: #8.2\n");
        System.out.println("*** СПИСОК СУЩЕСТВУЮЩИХ КОМАНД ***\n");
        System.out.println(" #1 Create или Создать\u001B[0m");
        System.out.println("      Создает новое задание");
        System.out.println(" \u001B[1m#2 Delete или Удалить\u001B[0m");
        System.out.println("      Удаляет задание");
        System.out.println(" \u001B[1m#3 Edit или Отредактировать\u001B[0m");
        System.out.println("      Позволяет отредактировать задание");
        System.out.println(" \u001B[1m#4 Complete или Выполнить\u001B[0m");
        System.out.println("      Помечает задание как выполненное");
        System.out.println(" \u001B[1m#5 Info, Describe или Информация\u001B[0m");
        System.out.println("      Выводит информацию о задании");
        System.out.println(" \u001B[1m#6.1 See all\u001B[0m");
        System.out.println("      Выводит все задания");
        System.out.println(" \u001B[1m#6.2 See done\u001B[0m");
        System.out.println("      Выводит выполненные задания");
        System.out.println(" \u001B[1m#6.3 See undone\u001B[0m");
        System.out.println("      Выводит невыполненные задания");
        System.out.println(" \u001B[1m#7.1 See all by due date\u001B[0m");
        System.out.println("      Выводит ВСЕ задания по дате выполнения");
        System.out.println(" \u001B[1m#7.2 See done by due date\u001B[0m");
        System.out.println("      Выводит ВЫПОЛНЕННЫЕ задания по дате выполнения");
        System.out.println(" \u001B[1m#7.3 See undone by due date\u001B[0m");
        System.out.println("      Выводит НЕВЫПОЛНЕННЫЕ задания по дате выполнения");
        System.out.println(" \u001B[1m#8.1 See all by creation date\u001B[0m");
        System.out.println("      Выводит ВСЕ задания по дате создания");
        System.out.println(" \u001B[1m#8.2 See done by creation date\u001B[0m");
        System.out.println("      Выводит ВЫПОЛНЕННЫЕ задания по дате создания");
        System.out.println(" \u001B[1m#8.3 See undone by creation date\u001B[0m");
        System.out.println("      Выводит НЕВЫПОЛНЕННЫЕ задания по дате создания\n");
    }
}