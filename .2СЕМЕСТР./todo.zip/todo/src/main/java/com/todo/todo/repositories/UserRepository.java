package com.todo.todo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.todo.todo.models.User;

public interface UserRepository extends JpaRepository<User, Integer>  {
    List<User> findByName(String name);  //поиск по имени пользователя
}
