package com.archive.archive.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.archive.archive.models.Order;

public interface OrderRepo extends JpaRepository<Order, Integer>{

    /**
     * Метод для получения заказов из БД по типу заказа
     * @param typeId id типа заказа
     * @return список заказов
     */
    List<Order> findByType(Integer typeId);

    /**
     * Метод для получения заказов из БД по типу заказа, 
     * сортированных по названию документа 
     * @param typeId id типа заказа
     * @return список заказов
     */
    List<Order> findByTypeOrderByDoc_Name(Integer typeId);

    /**
     * Метод для получения заказов из БД по типу заказа, 
     * сортированных по папке архива
     * @param typeId id типа заказа
     * @return список заказов
     */
    List<Order> findByTypeOrderByDoc_Folder(Integer typeId);

    /**
     * Метод для получения заказов из БД по типу заказа, 
     * сортированных по email заказчика
     * @param typeId id типа заказа 
     * @return список заказов
     */
    List<Order> findByTypeOrderByEmployee_Email(Integer typeId);

   /**
     * Метод для получения заказов из БД по типу заказа, 
     * сортированных по дате заказа 
     * @param typeId id типа заказа
     * @return список заказов
     */
    List<Order> findByTypeOrderByOrderDate(Integer typeId);
    
    
}
