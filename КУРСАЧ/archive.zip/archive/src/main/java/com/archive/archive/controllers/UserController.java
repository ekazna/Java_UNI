package com.archive.archive.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import com.archive.archive.models.Client;
import com.archive.archive.models.Department;
import com.archive.archive.models.Doc;
import com.archive.archive.models.DocType;
import com.archive.archive.models.Employee;
import com.archive.archive.models.TestModel;
import com.archive.archive.services.ClientService;
import com.archive.archive.services.DepartmentService;
import com.archive.archive.services.DocService;
import com.archive.archive.services.DocTypeService;
import com.archive.archive.services.EmployeeService;
import com.archive.archive.services.OrderService;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    DepartmentService departmentService;
    @Autowired
    ClientService clientService;
    @Autowired 
    DocService docService;
    @Autowired
    DocTypeService docTypeService;
    @Autowired
    EmployeeService employeeService;
    @Autowired 
    OrderService orderService;

 

    /**
     * Метод (GET), показывающий основную страницу для пользователя
     * с возможностью фильтрации и сортировки документов
     * @param model интерфейс для передачи данных на уровень представления 
     * @param testModel фильтры поиска и сортировки документов
     * @return ModelAndView объект html-страницу (основную)
     */
    @GetMapping("/")
    public ModelAndView viewAllDocs(Model model, @Param("testModel") TestModel testModel){
        List<Doc> listDocs = docService.getFilteredSpecification(testModel);
        
        List<Department> listDepts= departmentService.getAllSortedAsc();
        List<Client> listClients=clientService.getAllSortedAsc();
        List<DocType> listDocTypes=docTypeService.getAllSortedAsc();
        List<Employee> listEmployees=employeeService.getAllSortedAsc();
        model.addAttribute("listDocs", listDocs);
        model.addAttribute("listDepts", listDepts);
        model.addAttribute("listClients", listClients);
        model.addAttribute("listDocTypes", listDocTypes);
        model.addAttribute("listEmployees",listEmployees);
        return new ModelAndView("userDocs");
    }

    /**
     * Метод (POST) для добавления нового заказа на копию
     * @param id id документа
     * @return ModelAndView - перенаправляет на другую страницу (основную)
     */
    @PostMapping("/orderCopy/{id}")
    public ModelAndView orderCopy(@PathVariable Integer id){
        orderService.orderDoc(1, id);
        return new ModelAndView("redirect:/user/");
    }

    
    /**
     * Метод (POST) для добавления нового заказа на оригинал
     * @param id id документа
     * @return ModelAndView - перенаправляет на другую страницу (основную)
     */
    @PostMapping("/orderOriginal/{id}")
    public ModelAndView orderOriginal(@PathVariable Integer id){
        orderService.orderDoc(2, id);
        return new ModelAndView("redirect:/user/");
    }
    
    
    /**
     * Метод (GET) показывает страницу об авторе пользователю
     * @return ModelAndView объект html-страницу (об авторе)
     */
    @GetMapping("/about")
    public ModelAndView about(){
        return new ModelAndView("aboutAuthorForUser");
    }


}
