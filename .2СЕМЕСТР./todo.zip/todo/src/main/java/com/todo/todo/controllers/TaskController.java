package com.todo.todo.controllers;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.todo.todo.models.Task;
import com.todo.todo.models.User;
import com.todo.todo.services.TaskService;
import com.todo.todo.services.UserService;

@RestController
@RequestMapping("/tasks")
public class TaskController {
    @Autowired
    TaskService taskService;

    @Autowired
    UserService userService;

    @GetMapping("") // получить список всех задач
    public List<Task> getAllTasks(){
        return taskService.getAllTasks();
    }

    @GetMapping("/{id}") // получить задачу по id
    public ResponseEntity<Task> getTask(@PathVariable Integer id){
        try{
            Task task = taskService.getTaskById(id);
            return new ResponseEntity<Task>(task, HttpStatus.OK);
        }catch(NoSuchElementException e) {
            return new ResponseEntity<Task>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}") // изменить задачу по id
    public ResponseEntity<?> updateTask(@RequestBody Task task, @PathVariable Integer id){
        try{
            Task oldTask = taskService.getTaskById(id);
            oldTask.updateTask(task);
            taskService.saveTask(oldTask);
            return new ResponseEntity<>(HttpStatus.OK);
        }catch(NoSuchElementException e){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}/complete") // отметить задачу по id как выполненную
    public ResponseEntity<?> completeTask(@PathVariable Integer id){
        try{
            Task task = taskService.getTaskById(id);
            task.completeTask();
            taskService.saveTask(task);
            return new ResponseEntity<>(HttpStatus.OK);
        }catch(NoSuchElementException e){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{taskId}/category/{catId}") // добавить категорию в задачу
    public Task addTaskCategory(@PathVariable Integer taskId, @PathVariable Integer catId){
        return taskService.addTaskCategory(taskId, catId);
    }
    

    @DeleteMapping("/{id}")  // удалить задание по id
    public void deleteTask(@PathVariable Integer id){
        taskService.deleteTask(id);
    }

    @PostMapping("/by{id}") // добавить задание от имени пользователя (по id)
    public ResponseEntity<?> addTask(@RequestBody Task task, @PathVariable Integer id){
        try{
            User user = userService.getUserById(id);
            task.setUser(user);
            taskService.saveTask(task);
            return new ResponseEntity<>(HttpStatus.OK);
        }catch(NoSuchElementException e){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
