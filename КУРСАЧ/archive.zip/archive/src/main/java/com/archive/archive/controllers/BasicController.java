package com.archive.archive.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class BasicController {

    /**
     * Метод (GET) показывает страницу login
     * @return строку - представление html-страницы, которая 
     * показывается пользователю
     */
    @GetMapping("/login")
    public String login(){
        return "login";
    }

    /**
     * Метод для перенаправления пользователя на правильную страницу
     * после входа в систему в зависимости от его роли (USER или ADMIN)
     * @param request информация о запросе клиента
     * @return Возвращает строку - представление html страницы, на которую 
     * перенаправляется пользователь
     */
    @RequestMapping("/default")
    public String showFirstPage(HttpServletRequest request){
        if (request.isUserInRole("USER")) {
            return "redirect:/user/";
        } else if (request.isUserInRole("ADMIN")) {
            return "redirect:/admin/";
        }
        return "redirect:/login";
    }
      
}
