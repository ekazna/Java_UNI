package com.archive.archive.config;

import org.springframework.security.core.Authentication;

public interface IAuthenticationFacade {
    /**
     * Метод для получения информации о текущем пользователе
     * @return объект Authentification с информацией о пользователе
     */
    Authentication getAuthentication();
    
}
