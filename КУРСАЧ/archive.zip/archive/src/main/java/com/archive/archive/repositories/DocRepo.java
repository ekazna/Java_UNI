package com.archive.archive.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.archive.archive.models.Doc;

public interface DocRepo extends JpaRepository<Doc, Integer>, JpaSpecificationExecutor<Doc>{
    
    /**
     * @deprecated
     * Метод для получения списка документов по ключевому слову
     * @param keyword ключевое слово
     * @return список документов
     */
    @Query("SELECT d FROM Doc d WHERE d.name LIKE CONCAT('%',:keyword,'%')")
    List<Doc> searchKeyword(String keyword);


    /**
     * Метод для получения списка документов по номеру департамента
     * @param deptId номер департамента
     * @return список документов
     */
    @Query("SELECT d FROM Doc d WHERE d.department.id = :deptId")
    List<Doc> findByDeptId(Integer deptId);

    /**
     * @deprecated
     * Метод для получения списка документов по дате документа 
     * @param docDate
     * @return список документов
     */
    @Query("SELECT d FROM Doc d WHERE d.docDate = :docDate")
    List<Doc> getByDate(LocalDate docDate);

    /**
     * Метод для получения списка документов с истекшим сроком хранения
     * @param today текушая дата
     * @return список документов 
     */
    @Query("SELECT d FROM Doc d WHERE d.deletionDate <= :today ORDER BY d.folder")
    List<Doc> getDocsToDelete(LocalDate today);

    /**
     * Метод для получения статистики о количестве документов
     * от каждого департамента 
     * @return список списков - подсписок: название департамента, количество документов 
     */
    @Query(nativeQuery = true, value = "SELECT s.name, COUNT(d.id) FROM docs d FULL OUTER JOIN departments s USING(dept_id) GROUP BY s.name ORDER BY s.name")
    List<Object[]> deptStatistics();
    


}
