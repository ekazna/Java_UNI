package com.archive.archive.controllers;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.archive.archive.models.Client;
import com.archive.archive.models.Department;
import com.archive.archive.models.Doc;
import com.archive.archive.models.DocAction;
import com.archive.archive.models.DocType;
import com.archive.archive.models.Employee;
import com.archive.archive.models.Order;
import com.archive.archive.models.OrderSorting;
import com.archive.archive.models.TestModel;
import com.archive.archive.services.ClientService;
import com.archive.archive.services.DepartmentService;
import com.archive.archive.services.DocActionService;
import com.archive.archive.services.DocService;
import com.archive.archive.services.DocTypeService;
import com.archive.archive.services.EmployeeService;
import com.archive.archive.services.OrderService;


@RestController
@RequestMapping("/admin")
public class AdminController {


    @Autowired
    DepartmentService departmentService;
   
    @Autowired
    ClientService clientService;
   
    @Autowired 
    DocService docService;
    
    @Autowired
    DocTypeService docTypeService;
    
    @Autowired
    EmployeeService employeeService;
    
    @Autowired
    OrderService orderService;
    
    @Autowired 
    DocActionService docActionService;
    
    
    /**
     * Метод (GET), показывающий основную страницу для администратора
     * с возможностью фильтрации и сортировки документов 
     * 
     * @param model интерфейс для передачи данных на уровень представления 
     * @param testModel фильтры поиска и сортировки документов
     * @return ModelAndView объект html-страницу (основную)
     */
    @GetMapping("/")
    public ModelAndView viewAllDocs(Model model, @Param("testModel") TestModel testModel){

        List<Doc> listDocs = docService.getFilteredSpecification(testModel);
        
        List<Department> listDepts= departmentService.getAllSortedAsc();
        List<Client> listClients=clientService.getAllSortedAsc();
        List<DocType> listDocTypes=docTypeService.getAllSortedAsc();
        List<Employee> listEmployees=employeeService.getAllSortedAsc();
        model.addAttribute("listDocs", listDocs);
        model.addAttribute("listDepts", listDepts);
        model.addAttribute("listClients", listClients);
        model.addAttribute("listDocTypes", listDocTypes);
        model.addAttribute("listEmployees",listEmployees);
        return new ModelAndView("adminDocs");
    }


    /**
     * Метод (GET), показывающий страницу добавления документа
     * 
     * @param model интерфейс для передачи данных на уровень представления 
     * @param doc объект-документ
     * @return ModelAndView объект html-страницу (добавления)
     */
    @GetMapping("/add/")
    public ModelAndView addDoc(Model model, @Param("doc") Doc doc){

        List<Department> listDepts= departmentService.getAllSortedAsc();
        List<Client> listClients=clientService.getAllSortedAsc();
        List<DocType> listDocTypes=docTypeService.getAllSortedAsc();
        List<Employee> listEmployees=employeeService.getAllSortedAsc();
        model.addAttribute("listDepts", listDepts);
        model.addAttribute("listClients", listClients);
        model.addAttribute("listDocTypes", listDocTypes);
        model.addAttribute("listEmployees",listEmployees);

        return new ModelAndView("adminAddDoc");
    }

    /**
     * Метод (POST) для добавления документа 
     * @param model интерфейс для передачи данных на уровень представления 
     * @param doc объект-документ для сохранения
     * @return ModelAndView - перенаправляет на другую страницу (добавления документа)
     */
    @PostMapping("/add/save/")
    public ModelAndView saveDoc(Model model, @ModelAttribute Doc doc){
        docService.save(doc);
        return new ModelAndView("redirect:/admin/add/");
    }

    
    /**
     * Метод (DELETE) для удаления документа по ID
     * @param id id удаляемого документа
     * @return ModelAndView - перенаправляет на другую страницу (основную)
     */
    @DeleteMapping("/delete/{id}")
    public ModelAndView deleteDoc(@PathVariable Integer id){
        docService.delete(id);
        return new ModelAndView("redirect:/admin/");
    }

    
    /**
     * Метод (GET) для редактирования документа по id
     * @param model интерфейс для передачи данных на уровень представления 
     * @param id id редактируемого документа
     * @param doc объект-документ
     * @return ModelAndView объект html-страницу (редактирования)
     */
    @GetMapping("/edit/{id}")
    public ModelAndView editDoc(Model model, @PathVariable Integer id, @Param("doc") Doc doc){
        doc = docService.getById(id);
        model.addAttribute(doc);

        List<Department> listDepts= departmentService.getAllSortedAsc();
        List<Client> listClients=clientService.getAllSortedAsc();
        List<DocType> listDocTypes=docTypeService.getAllSortedAsc();
        List<Employee> listEmployees=employeeService.getAllSortedAsc();
        model.addAttribute("listDepts", listDepts);
        model.addAttribute("listClients", listClients);
        model.addAttribute("listDocTypes", listDocTypes);
        model.addAttribute("listEmployees",listEmployees);


        return new ModelAndView("adminEditDoc");


    }

    /**
     * Метод (PUT) редактирования информации о документе
     * @param id id редактируемого документа
     * @param model интерфейс для передачи данных на уровень представления 
     * @param doc объект-документ
     * @return ModelAndView - перенаправляет на другую страницу (основную)
     */
    @PutMapping("/edit/{id}/updating/")
    public ModelAndView updateDoc(@PathVariable Integer id, Model model, @ModelAttribute Doc doc){
        docService.update(doc);
        return new ModelAndView("redirect:/admin/");
    }



    /**
     * Метод (GET) для просмотра заказанных копий 
     * @param model интерфейс для передачи данных на уровень представления
     * @param orderSorting объект для применения сортировки к списку документов
     * @return ModelAndView объект html-страницу (заказов на копии)
     */
    @GetMapping("/copies/")
    public ModelAndView seeCopyOrders(Model model, @Param("orderSorting") OrderSorting orderSorting){
        List<Order> orderList= orderService.findByTypeAndSort(1, orderSorting);
        model.addAttribute("orderList", orderList);

        return new ModelAndView("adminCopyOrders");
    }

    /**
     * Метод (DELETE) для удаления информации о заказе копии
     * @param id id заказа
     * @return ModelAndView - перенаправляет на другую страницу (заказов копий)
     */
    @DeleteMapping("/copies/{id}")
    public ModelAndView copyOrderComplete(@PathVariable Integer id){
        orderService.deleteCopyOrder(id);
        return new ModelAndView("redirect:/admin/copies/");
    }


    /**
     * Метод (GET) для просмотра заказанных оригиналов
     * @param model интерфейс для передачи данных на уровень представления 
     * @param orderSorting объект для применения сортировки к списку документов
     * @return ModelAndView объект html-страницу (заказов на оригиналы)
     */
    @GetMapping("/originals/")
    public ModelAndView seeOriginalOrders(Model model, @Param("orderSorting") OrderSorting orderSorting){
        List<Order> orderList= orderService.findByTypeAndSort(2, orderSorting);
        model.addAttribute(orderList);

        return new ModelAndView("adminOriginalOrders");
    }


    /**
     * Метод (PUT) для изменения статуса заказа оригинала 
     * @param id id заказа
     * @return ModelAndView - перенаправляет на другую страницу (заказов на оригиналы)
     */
    @PutMapping("/originals/{id}")
    public ModelAndView issueOriginal(@PathVariable Integer id){
        orderService.updateType(id);
        return new ModelAndView("redirect:/admin/originals/");
    }


    /**
     * Метод (GET) для просмотра выписанных документов
     * @param model интерфейс для передачи данных на уровень представления 
     * @param orderSorting объект для применения сортировки к списку документов
     * @return ModelAndView объект html-страницу (возврата оригиналов)
     */
    @GetMapping("/returns/")
    public ModelAndView returnOriginalOrders(Model model, @Param("orderSorting") OrderSorting orderSorting){
        List<Order> orderList= orderService.findByTypeAndSort(3, orderSorting);
        model.addAttribute(orderList);

        return new ModelAndView("adminDocReturns");
    }

    /**
     * Метод (DELETE) для удаления заказа на оригинал после возврата
     * @param id id заказа
     * @return ModelAndView - перенаправляет на другую страницу (возврата оригиналов)
     */
    @DeleteMapping("/returns/{id}")
    public ModelAndView returnComplete(@PathVariable Integer id){
        orderService.returnOrder(id);
        return new ModelAndView("redirect:/admin/returns/");
    }

    /**
     * Метод (GET) для просмотра статистики архива
     * @param model интерфейс для передачи данных на уровень представления 
     * @return ModelAndView объект html-страницу (статистики)
     */
    @GetMapping("/statistics/")
    public ModelAndView seeStatistics(Model model){
        HashMap<String, Long> statsList = docActionService.actStatistics();
        model.addAttribute("statsList", statsList);
        HashMap<String, Long> deptStatsList = docService.deptStatistics();
        model.addAttribute("deptStatsList", deptStatsList);
        

        List<DocAction> actionList = docActionService.getAll();
        model.addAttribute("actionList", actionList);
        
        return new ModelAndView("adminStatistics");
    }


    /**
     * Метод (GET) для просмотра документов с истекшим сроком хранения
     * @param model интерфейс для передачи данных на уровень представления 
     * @return ModelAndView объект html-страницу (документов на удаление)
     */
    @GetMapping("/expired/")
    public ModelAndView viewExpiredDocs(Model model){

        List<Doc> listDocs = docService.getDocsToDelete();
        model.addAttribute("listDocs", listDocs);
        return new ModelAndView("adminExpired");
    }

    /**
     * Метод (DELETE) для удаления документа по id
     * @param id id документа
     * @return ModelAndView - перенаправляет на другую страницу (документов на удаление)
     */
    @DeleteMapping("/expired/delete/{id}")
    public ModelAndView deleteExpiredDoc(@PathVariable Integer id){
        docService.delete(id);
        return new ModelAndView("redirect:/admin/expired/");
    }

    /**
     * Метод (GET) показывает страницу об авторе администратору
     * @return ModelAndView объект html-страницу (об авторе)
     */
    @GetMapping("/about")
    public ModelAndView about(){
        return new ModelAndView("aboutAuthor");
    }

}
