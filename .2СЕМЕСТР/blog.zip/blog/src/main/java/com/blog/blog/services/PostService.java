package com.blog.blog.services;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.blog.models.Category;
import com.blog.blog.models.Post;
import com.blog.blog.repositories.CategoryRepository;
import com.blog.blog.repositories.PostRepository;

import jakarta.transaction.Transactional;


@Service
@Transactional
public class PostService {
    @Autowired
    private PostRepository postRepository;
    @Autowired
    private CategoryRepository categoryRepository;

    public List<Post> getAllPosts(){
        return postRepository.findAll();
    }

    public Post getPostById(Integer id){
        return postRepository.findById(id).get();
    }

    public void savePost(Post post){
        postRepository.save(post);
    }

    public void deletePost(Integer id){
        postRepository.deleteById(id);
    }

    public Post addPostCategory(Integer postId, Integer catId){  //добавление категории к посту
        Category category = categoryRepository.findById(catId).get();
        Post post = postRepository.findById(postId).get();
        Set<Category> categorySet = post.getCategories();
        categorySet.add(category);
        post.setCategories(categorySet);
        return postRepository.save(post);
    }
}
