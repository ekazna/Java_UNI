import java.util.ArrayList;
import java.util.Calendar;

public class Schedule {
    ArrayList<Task> mySchedule;
    int idCounter;

    Schedule() {
        this.mySchedule = new ArrayList<Task>();
        this.idCounter = 1;
    }

    public void addTask(Task newTask) {
        this.mySchedule.add(newTask);
        newTask.id = this.idCounter;
        this.idCounter++;
    }

    public void addTask(String name, Calendar dueDate) {
        Task newTask = new Task(name, dueDate);
        this.mySchedule.add(newTask);
        newTask.id = this.idCounter;
        this.idCounter++;
    }

    public void addTask(String name, Calendar dueDate, String description) {
        Task newTask = new Task(name, dueDate, description);
        this.mySchedule.add(newTask);
        newTask.id = this.idCounter;
        this.idCounter++;
    }


    // печатает информацию о всех заданиях
    public void printAllTasks() {
        System.out.println("*****************************");
        for (Task task : this.mySchedule) {
            System.out.println("Task " + task.id + ": " + task.name);
        }
        System.out.println("*****************************");
    }

    // печатает информацию о всех выполненных заданиях
    public void printDoneTasks() {
        System.out.println("*****************************");
        for (Task task : this.mySchedule) {
            if (task.done) {
                System.out.println("Task " + task.id + ": " + task.name);
            }
        }
        System.out.println("*****************************");
    }

    // печатает информацию о всех невыполненных заданиях
    public void printUndoneTasks(){
        System.out.println("*****************************");
        for (Task task:this.mySchedule) {
            if (!task.done){
                System.out.println("Task " + task.id + ": " + task.name);
            }
        }
        System.out.println("*****************************");
    }

    // печатает информацию о всех заданиях по дате выполнения
    public void printAllTasksByDueDate(Calendar dueDate) {
        System.out.println("*****************************");
        for (Task task : this.mySchedule) {
            if(equalDates(task.dueDate, dueDate)){
                System.out.println("Task " + task.id + ": " + task.name);
            }
        }
        System.out.println("*****************************");
    }

    // печатает информацию о всех выполненных заданиях по дате выполнения
    public void printDoneTasksByDueDate(Calendar dueDate) {
        System.out.println("*****************************");
        for (Task task : this.mySchedule) {
            if (task.done & equalDates(task.dueDate, dueDate)) {
                System.out.println("Task " + task.id + ": " + task.name);
            }
        }
        System.out.println("*****************************");
    }

    // печатает информацию о всех невыполненных заданиях по дате выполнения
    public void printUndoneTasksByDueDate(Calendar dueDate){
        System.out.println("*****************************");
        for (Task task:this.mySchedule) {
            if (!task.done & equalDates(task.dueDate, dueDate)){
                System.out.println("Task " + task.id + ": " + task.name);
            }
        }
        System.out.println("*****************************");
    }

    // печатает информацию о всех заданиях по дате создания
    public void printAllTasksByCreationDate(Calendar creationDate) {
        System.out.println("*****************************");
        for (Task task : this.mySchedule) {
            if(equalDates(task.creationDate, creationDate)){
                System.out.println("Task " + task.id + ": " + task.name);
            }
        }
        System.out.println("*****************************");
    }

    // печатает информацию о всех выполненных заданиях по дате создания
    public void printDoneTasksByCreationDate(Calendar creationDate) {
        System.out.println("*****************************");
        for (Task task : this.mySchedule) {
            if (task.done & equalDates(task.creationDate, creationDate)) {
                System.out.println("Task " + task.id + ": " + task.name);
            }
        }
        System.out.println("*****************************");
    }

    // печатает информацию о всех невыполненных заданиях по дате создания
    public void printUndoneTasksByCreationDate(Calendar creationDate){
        System.out.println("*****************************");
        for (Task task:this.mySchedule) {
            if (!task.done & equalDates(task.creationDate, creationDate)){
                System.out.println("Task " + task.id + ": " + task.name);
            }
        }
        System.out.println("*****************************");
    }


    // Проверяет одинаковы ли даты
    public boolean equalDates(Calendar date1, Calendar date2){
        return date1.get(Calendar.YEAR) == date2.get(Calendar.YEAR) &
                date1.get(Calendar.MONTH) == date2.get(Calendar.MONTH) &
                date1.get(Calendar.DATE) == date2.get(Calendar.DATE);
    }
}

