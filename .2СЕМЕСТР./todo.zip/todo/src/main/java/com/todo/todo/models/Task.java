package com.todo.todo.models;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Set;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;
/* Задание имеет следующие атрибуты:

Уникальный идентификатор
Наименование
Описание
Дата выполнения
Выполнено (значение Да/Нет)
Категория
Пользователь*/


@Entity
@Table(name = "tasks")
@Data
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name;
    private String description;
    private LocalDate completionDate;
    @Column(columnDefinition = "boolean default false")
    private Boolean completed;

    @CreationTimestamp
    private Instant createdOn;

    @UpdateTimestamp
    private Instant lastUpdatedOn;
    

    @ManyToOne  //отношения многие к одному с users
    @JoinColumn(name = "user_id", nullable = false)
    private User user;


    @ManyToMany  //отношение многие ко многим с categories через дополнительную таблицу 
    @JoinTable(
            name = "task_categories",
            joinColumns = {@JoinColumn(name = "task_id")},
            inverseJoinColumns = {@JoinColumn(name = "category_id")})
    private Set<Category> categories;

    public void updateTask(Task task){  //метод для изменения информации о задании
        if (task.name != null){
            this.name = task.name;
        }
        if (task.description != null){
            this.description = task.description;
        }
        
    }

    public void completeTask(){ // метод помечает задание как выполненное и устанавливает дату выполнения
        this.completed = true;
        this.completionDate = LocalDate.now();
    }
}


