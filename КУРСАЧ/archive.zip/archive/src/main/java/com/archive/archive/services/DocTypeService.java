package com.archive.archive.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.archive.archive.models.DocType;
import com.archive.archive.repositories.DocTypeRepo;

import jakarta.transaction.Transactional;


@Service
@Transactional
public class DocTypeService {
    @Autowired
    DocTypeRepo docTypeRepo;


    /**
     * Метод для получения списка всех типов документов 
     * @return список типов документов 
     */
    public List<DocType> getAll(){
        return docTypeRepo.findAll();
    }

    /**
     * Метод для получения списка всех типов документов, 
     * сортированных по названию типа
     * @return сортированный список типов документов 
     */
    public List<DocType> getAllSortedAsc(){
        return docTypeRepo.findAll(Sort.by("name"));
    }
}
