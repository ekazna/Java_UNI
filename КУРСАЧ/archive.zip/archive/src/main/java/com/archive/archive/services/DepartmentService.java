package com.archive.archive.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.archive.archive.models.Department;
import com.archive.archive.repositories.DepartmentRepo;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class DepartmentService {
    @Autowired
    DepartmentRepo departmentRepo;

    /**
     * Метод для получения списка всех отделов
     * @return список отделов
     */
    public List<Department> getAll(){
        return departmentRepo.findAll();
    }
    
    /**
     * Метод для получения списка отделов, сортированных по названию
     * @return список отделов, сортированных по названию по алфавиту 
     */
    public List<Department> getAllSortedAsc(){
        return departmentRepo.findAll(Sort.by("name"));
    }

    /**
     * Метод для получения отдела по id
     * @param id id отдела
     * @return отдел
     */
    public Department findById(Integer id){
        return departmentRepo.findById(id).get();
    }

}
