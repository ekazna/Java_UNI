package com.todo.todo.services;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.todo.todo.models.Category;
import com.todo.todo.models.Task;
import com.todo.todo.repositories.CategoryRepository;
import com.todo.todo.repositories.TaskRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class TaskService {
    @Autowired
    TaskRepository taskRepository;

    @Autowired
    CategoryRepository categoryRepository;

    public List<Task> getAllTasks(){
        return taskRepository.findAll();
    }

    public Task getTaskById(Integer id){
        return taskRepository.findById(id).get();
    }

    public void saveTask(Task task){
        taskRepository.save(task);
    }

    public void deleteTask(Integer id){
        taskRepository.deleteById(id);
    }

    public Task addTaskCategory(Integer taskId, Integer catId){  // добавить категорию в задание 
        Task task = taskRepository.findById(taskId).get();
        Category category = categoryRepository.findById(catId).get();
        Set<Category> categorySet = task.getCategories();
        categorySet.add(category);
        task.setCategories(categorySet);
        return taskRepository.save(task);

    }
}
